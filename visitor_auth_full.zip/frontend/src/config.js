export const API_BASE = 'https://YOUR_BACKEND_URL/api'; // replace with your backend URL or ngrok URL
