Visitor Auth App - GitHub Ready
- frontend/ (expo)
- backend/ (node)

Upload both folders into your GitHub repo root and commit.
Then import the repo into Expo (expo.dev) and build APK.
